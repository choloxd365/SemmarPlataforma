<?php 

const SERVERURL="http://localhost/SemmarPlataforma/";
const COMPANYNAME="SEMMAR";
date_default_timezone_get();


?>