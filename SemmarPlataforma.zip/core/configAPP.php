<?php 

		const SERVER="localhost";
		const DB="semmarplataforma";
		const USER="root";
		const PASS="";

		const SGBD="mysql:host=".SERVER.";dbname=".DB;

		const METHOD="AES-256-CBC";
		const SECRET_KEY='$BP@2017';
		const SECRET_IV='101712';

		