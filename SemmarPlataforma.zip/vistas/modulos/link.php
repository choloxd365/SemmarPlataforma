

    <link rel="stylesheet" href="<?php echo SERVERURL;?>vistas/vendors/iconfonts/mdi/css/materialdesignicons.css">
    <link rel="stylesheet" href="<?php echo SERVERURL;?>vistas/vendors/css/vendor.addons.css" />
    <link rel="stylesheet" href="<?php echo SERVERURL;?>vistas/css/shared/style.css">
    <!-- endinject -->
    <!-- Layout style -->
    <link rel="stylesheet" href="<?php echo SERVERURL;?>vistas/css/demo_1/style.css">
    <!-- Layout style -->
    <link rel="shortcut icon" href="<?php echo SERVERURL;?>vistas/images/favicon.ico" />
    
    <link rel="stylesheet" href="<?php echo SERVERURL;?>vistas/css/sweetalert2.css">

    <script src="<?php echo SERVERURL;?>vistas/vendors/js/core.js"></script>
    <script src="<?php echo SERVERURL;?>vistas/vendors/apexcharts/apexcharts.min.js"></script>
    <script src="<?php echo SERVERURL;?>vistas/vendors/chartjs/Chart.min.js"></script>
    <script src="<?php echo SERVERURL;?>vistas/js/charts/chartjs.addon.js"></script>
    <script src="<?php echo SERVERURL;?>vistas/js/template.js"></script>
    <script src="<?php echo SERVERURL;?>vistas/js/dashboard.js"></script>
    <script src="<?php echo SERVERURL;?>vistas/js/inputDinamico.js"></script>
    <script src="<?php echo SERVERURL;?>vistas/js/sweetalert2.min.js"></script>
    <script src="<?php echo SERVERURL;?>vistas/js/funcioncarlos.js"></script>
    
    