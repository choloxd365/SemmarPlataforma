<body>
    <div class="error_page error_2">
      <div class="container inner-wrapper">
        <h1 class="display-1 error-heading">404</h1>
        <h2 class="error-code">Page no Encontrada!</h2>
        <p class="error-message">Esta pagina no fue encontrada dentro del sistema, por favor verifique el link del enlace y vuelva a intentarlo, Gracias</p>
        <a href="<?php echo SERVERURL ?>" class="btn btn-primary">Ir al inicio</a>
      </div>
    </div>
</body>